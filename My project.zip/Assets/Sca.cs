using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sca : MonoBehaviour
{
    public GameObject asd;
    Rigidbody2D asdRb;
    public bool ww = false;
    public bool wda = false;
    public float speed = 7;
    int i = 0;
    CameraShake cm;
    // Start is called before the first frame update
    void Start()
    {
        asdRb = GetComponent<Rigidbody2D>();
        cm = Camera.main.GetComponent<CameraShake>();

    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxisRaw("Horizontal");
        float z = Input.GetAxisRaw("Vertical");

        transform.Translate(x * speed * Time.deltaTime, 0, 0);

        if (Input.GetKeyDown(KeyCode.Space))
        {
            i++;
          

            if (i % 2 == 0)
            {
                ww = false;
            }
            else if (i % 2 == 1)
            {
                ww = true;
            }

        }


        if(Input.GetKey(KeyCode.LeftShift))
        {
            speed = 15;
        }
        if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            speed = 7;
        }

        if (ww)
        {
            asdRb.gravityScale = -1 * Time.time;
        }
        else
        {
            asdRb.gravityScale = 1 * Time.time;
        }
    }
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("wall"))
        {
            StartCoroutine(cm.Shake(0.2f, 0.5f));
        }
    }
}
