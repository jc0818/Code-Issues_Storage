using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraShake : MonoBehaviour
{
   

    public IEnumerator Shake(float duration, float magnitude)
    {
        Vector3 originalPos = new Vector3(0, 0, -50);

        float ellapsedTime = 0f;

        while(ellapsedTime < duration)
        {
            float xo  = Random.Range(-1.0f, 1.0f) * magnitude;
            float yo = Random.Range(-1.0f, 1.0f) * magnitude;
            transform.localPosition = new Vector3(xo, yo, originalPos.z);

            ellapsedTime += Time.deltaTime;
            yield return null;
        }
        transform.localPosition = originalPos;
        
    }
}
